package com.thep.controller

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private val CYAN = Color.parseColor("#00E5FF")
private val MAGENTA = Color.parseColor("#FF2BD6")
private val LIME = Color.parseColor("#39FF14")
private val RED = Color.parseColor("#FF1744")
private val ORANGE = Color.parseColor("#FF9100")
private val YELLOW = Color.parseColor("#FFEA00")

private fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

private fun lerpColor(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt()
    val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt()
    val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
    return Color.rgb(r, g, bl)
}

// สีตามกำลัง: ฟ้า -> ชมพู -> แดง
private fun heat(p: Float): Int =
    if (p < 0.5f) lerpColor(CYAN, MAGENTA, p * 2f) else lerpColor(MAGENTA, RED, (p - 0.5f) * 2f)

// ---------------------------------------------------------------
// พื้นหลังกริดสำหรับหน้าเมนู
// ---------------------------------------------------------------
class GridBackground(ctx: Context) : View(ctx) {
    private val bg = Paint()
    private val g1 = Paint()
    private val g2 = Paint()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2f }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bg.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(Color.parseColor("#14002E"), Color.parseColor("#05060F"), Color.parseColor("#00202B")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        g1.shader = RadialGradient(w * 0.12f, h * 0.95f, w * 0.5f, withAlpha(MAGENTA, 80), 0, Shader.TileMode.CLAMP)
        g2.shader = RadialGradient(w * 0.92f, h * 0.05f, w * 0.5f, withAlpha(CYAN, 70), 0, Shader.TileMode.CLAMP)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, bg)
        c.drawRect(0f, 0f, w, h, g1)
        c.drawRect(0f, 0f, w, h, g2)
        val horizon = h * 0.5f
        for (i in 0 until 9) {
            val f = ((i + t * 9f) % 9f) / 9f
            val y = horizon + (h - horizon) * f * f
            line.color = withAlpha(CYAN, (20 + 70 * f).toInt())
            c.drawLine(0f, y, w, y, line)
        }
        for (k in -12..12) {
            line.color = withAlpha(MAGENTA, 38)
            c.drawLine(w / 2f + k * w * 0.02f, horizon, w / 2f + k * w * 0.10f, h, line)
        }
    }
}

// ---------------------------------------------------------------
// ปุ่มนีออน (หน้าเมนู)
// ---------------------------------------------------------------
class NeonButton(
    ctx: Context,
    private val label: String,
    private val neon: Int,
    private val textSizeSp: Float = 14f
) : View(ctx) {
    var onClick: (() -> Unit)? = null
    private var down = false
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
        color = neon
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = 12f * d
        rect.set(m, m, w - m, h - m)
        val r = 22f * d
        fill.color = withAlpha(neon, if (down) 130 else 28)
        c.drawRoundRect(rect, r, r, fill)
        stroke.setShadowLayer(if (down) 28f * d else 12f * d, 0f, 0f, neon)
        c.drawRoundRect(rect, r, r, stroke)
        txt.textSize = textSizeSp * d
        c.drawText(label, w / 2f, h / 2f + txt.textSize / 3f, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; invalidate(); performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }
            MotionEvent.ACTION_UP -> { if (down) { down = false; invalidate(); onClick?.invoke() } }
            MotionEvent.ACTION_CANCEL -> { down = false; invalidate() }
        }
        return true
    }
}

// ---------------------------------------------------------------
// หน้าขับรถ v4: แผงควบคุมเต็มจอ (วาดเองทั้งหมด + มัลติทัช)
//   ซ้าย  = คันเร่ง/ถอย (แนวตั้ง)   ขวา = พวงมาลัย (แนวนอน)
//   เอฟเฟกต์: ไฟหน้า, เปลวไฟท้าย, สายฟ้า, คลื่นกระแทก, จอสั่น, redline
// ---------------------------------------------------------------
class DriveView(ctx: Context) : View(ctx) {
    @Volatile var outL = 0           // -100..100 (คำสั่งที่ส่งไป ESP32)
    @Volatile var outR = 0
    @Volatile var lastTeleMs = 0L
    @Volatile var spdL = 0f          // ความเร็วจริงจาก ESP32 (cm/s) ถ้ามี encoder
    @Volatile var spdR = 0f
    @Volatile var enc = false
    var estop = false
    var gear = 1                     // 0 ECO, 1 SPORT, 2 TURBO
    var pivot = false                // false = หมุนอยู่กับที่ (2 ฝั่ง) / true = หมุนรอบล้อเดียว
    var deviceName = "-"
    var onDisconnect: (() -> Unit)? = null
    var onSetup: (() -> Unit)? = null

    private var W = 1f
    private var H = 1f
    private var hu = 1f

    private var thrIn = 0f
    private var steerIn = 0f
    private var thrId = -1
    private var steerId = -1
    private var thrVis = 0f
    private var steerVis = 0f
    private var dispL = 0f
    private var dispR = 0f
    private var power = 0f
    private var avg = 0f
    private var spdDisp = 0f
    private var spdMax = 0f

    private var lastNs = 0L
    private var clock = 0f
    private var gridT = 0f
    private var intro = 0f
    private var sparkAcc = 0f
    private var shakeX = 0f
    private var shakeY = 0f

    private val rnd = java.util.Random()
    private val NS = 40
    private val sx = FloatArray(NS)
    private val sy = FloatArray(NS)
    private val sv = FloatArray(NS)
    private val sl = FloatArray(NS)
    private val NP = 64
    private val px = FloatArray(NP)
    private val py = FloatArray(NP)
    private val pvx = FloatArray(NP)
    private val pvy = FloatArray(NP)
    private val pl = FloatArray(NP)
    private val ringAge = FloatArray(3) { -1f }
    private val ringCol = IntArray(3)

    private val bg = Paint()
    private val g1 = Paint()
    private val g2 = Paint()
    private val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val oval = RectF()
    private val path = Path()

    private val rDisc = RectF()
    private val rSetup = RectF()
    private val rGear = Array(3) { RectF() }
    private val rMode = RectF()
    private val rEstop = RectF()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        W = w.toFloat(); H = h.toFloat(); hu = H / 100f
        bg.shader = LinearGradient(
            0f, 0f, 0f, H,
            intArrayOf(Color.parseColor("#16002F"), Color.parseColor("#05060F"), Color.parseColor("#00202B")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        g1.shader = RadialGradient(W * 0.1f, H * 0.95f, W * 0.45f, withAlpha(MAGENTA, 70), 0, Shader.TileMode.CLAMP)
        g2.shader = RadialGradient(W * 0.92f, H * 0.05f, W * 0.45f, withAlpha(CYAN, 60), 0, Shader.TileMode.CLAMP)
        rDisc.set(W * 0.82f, H * 0.025f, W * 0.97f, H * 0.105f)
        rSetup.set(W * 0.66f, H * 0.025f, W * 0.80f, H * 0.105f)
        val gx0 = W * 0.32f
        val gap = W * 0.008f
        val bw = (W * 0.36f - 2 * gap) / 3f
        for (i in 0..2) rGear[i].set(gx0 + i * (bw + gap), H * 0.715f, gx0 + i * (bw + gap) + bw, H * 0.825f)
        rMode.set(W * 0.32f, H * 0.855f, W * 0.49f, H * 0.96f)
        rEstop.set(W * 0.50f, H * 0.855f, W * 0.68f, H * 0.96f)
        for (i in 0 until NS) {
            sx[i] = rnd.nextFloat() * W
            sy[i] = rnd.nextFloat() * H
            sv[i] = 0.6f + rnd.nextFloat() * 0.8f
            sl[i] = 0.5f + rnd.nextFloat() * 1.0f
        }
    }

    fun resetInputs() {
        thrIn = 0f; steerIn = 0f; thrId = -1; steerId = -1
    }

    private fun ring(color: Int) {
        for (i in 0 until 3) if (ringAge[i] < 0f) { ringAge[i] = 0f; ringCol[i] = color; return }
        ringAge[0] = 0f; ringCol[0] = color
    }

    // ---------------- ทัช ----------------
    private fun haptic() { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    private fun hitButtons(x: Float, y: Float): Boolean {
        if (rDisc.contains(x, y)) { onDisconnect?.invoke(); return true }
        if (rSetup.contains(x, y)) { haptic(); onSetup?.invoke(); return true }
        for (i in 0..2) if (rGear[i].contains(x, y)) {
            if (gear != i) ring(if (i == 2) RED else if (i == 0) LIME else CYAN)
            gear = i; haptic(); return true
        }
        if (rMode.contains(x, y)) { pivot = !pivot; haptic(); return true }
        if (rEstop.contains(x, y)) {
            estop = !estop
            if (estop) { thrIn = 0f; steerIn = 0f }
            ring(RED)
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            return true
        }
        return false
    }

    private fun setThr(y: Float) {
        val top = H * 0.21f
        val bot = H * 0.93f
        val mid = (top + bot) / 2f
        thrIn = ((mid - y) / ((bot - top) / 2f)).coerceIn(-1f, 1f)
    }

    private fun setSteer(x: Float) {
        steerIn = ((x - W * 0.85f) / (W * 0.13f)).coerceIn(-1f, 1f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                val x = e.getX(i)
                val y = e.getY(i)
                if (!hitButtons(x, y)) {
                    if (x < W * 0.30f && y > H * 0.12f && thrId == -1) { thrId = id; setThr(y) }
                    else if (x > W * 0.70f && y > H * 0.12f && steerId == -1) { steerId = id; setSteer(x) }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    if (id == thrId) setThr(e.getY(i))
                    if (id == steerId) setSteer(e.getX(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = e.getPointerId(e.actionIndex)
                if (id == thrId) { thrId = -1; thrIn = 0f }
                if (id == steerId) { steerId = -1; steerIn = 0f }
            }
            MotionEvent.ACTION_CANCEL -> resetInputs()
        }
        return true
    }

    // ---------------- คำนวณคำสั่งมอเตอร์ ----------------
    // เส้นโค้ง: ช่วงต้นละเอียด (ควบคุมช้าๆ ได้) ช่วงปลายแรง
    private fun expo(x: Float): Float {
        val a = abs(x)
        if (a < 0.04f) return 0f
        val n = (a - 0.04f) / 0.96f
        val v = 0.40f * n + 0.60f * n * n * n
        return if (x < 0f) -v else v
    }

    private fun update(dt: Float) {
        val cap = when (gear) { 0 -> 0.45f; 1 -> 0.75f; else -> 1f }
        val t = expo(thrIn) * cap
        val s = expo(steerIn) * max(0.55f, cap)
        var l: Float
        var r: Float
        if (pivot && abs(t) < 0.08f && abs(s) > 0.02f) {
            // หมุนรอบล้อเดียว: ใช้มอเตอร์ฝั่งนอกฝั่งเดียว
            if (s > 0f) { l = s; r = 0f } else { l = 0f; r = -s }
        } else {
            // ผสมแบบ arcade: t=0 จะหมุนอยู่กับที่ (ซ้ายถอย ขวาเดินหน้า)
            l = t + s
            r = t - s
            val m = max(1f, max(abs(l), abs(r)))
            l /= m
            r /= m
        }
        if (estop) { l = 0f; r = 0f }
        outL = (l * 100f).roundToInt()
        outR = (r * 100f).roundToInt()

        val k = min(1f, dt * 12f)
        dispL += (l - dispL) * k
        dispR += (r - dispR) * k
        power = max(abs(dispL), abs(dispR)).coerceIn(0f, 1f)
        avg = (dispL + dispR) / 2f

        // ความเร็ว: ใช้ค่าจริงจาก encoder ถ้ามี ไม่งั้นประมาณจากกำลัง
        val target = if (enc) abs(spdL + spdR) / 2f else abs(avg) * 100f
        spdDisp += (target - spdDisp) * min(1f, dt * 8f)
        if (spdDisp > spdMax) spdMax = spdDisp

        val kv = min(1f, dt * 16f)
        thrVis = if (thrId != -1) thrIn else thrVis - thrVis * kv
        steerVis = if (steerId != -1) steerIn else steerVis - steerVis * kv

        val dir = if (avg >= 0f) 1f else -1f
        gridT += dt * (0.25f + 2.6f * power) * dir
        for (i in 0 until NS) {
            sy[i] += dir * dt * H * (0.05f + 3.0f * power) * sv[i]
            val len = H * (0.02f + 0.32f * power) * sl[i]
            if (sy[i] - dir * len > H + len && dir > 0f) { sy[i] = -len; sx[i] = rnd.nextFloat() * W }
            if (sy[i] < -len && dir < 0f) { sy[i] = H + len; sx[i] = rnd.nextFloat() * W }
        }

        // จอสั่นตอน TURBO แรงๆ
        if (gear == 2 && power > 0.8f && !estop) {
            val a = (power - 0.8f) * 5f * hu * 0.5f
            shakeX = (rnd.nextFloat() - 0.5f) * a
            shakeY = (rnd.nextFloat() - 0.5f) * a
        } else { shakeX = 0f; shakeY = 0f }

        for (i in 0 until 3) if (ringAge[i] >= 0f) { ringAge[i] += dt * 1.1f; if (ringAge[i] > 1f) ringAge[i] = -1f }

        // ประกายไฟท้ายรถ
        if (power > 0.30f) {
            sparkAcc += dt * power * 110f
            while (sparkAcc >= 1f) {
                sparkAcc -= 1f
                for (j in 0 until NP) {
                    if (pl[j] <= 0f) {
                        px[j] = W * 0.5f + (rnd.nextFloat() - 0.5f) * hu * 7f
                        py[j] = H * 0.40f + dir * hu * 14f
                        pvx[j] = (rnd.nextFloat() - 0.5f) * hu * 46f
                        pvy[j] = dir * H * (0.3f + rnd.nextFloat() * 1.0f)
                        pl[j] = 1f
                        break
                    }
                }
            }
        }
        for (j in 0 until NP) {
            if (pl[j] > 0f) {
                px[j] += pvx[j] * dt
                py[j] += pvy[j] * dt
                pl[j] -= dt * 1.7f
            }
        }
    }

    // ---------------- ตัวช่วยวาด ----------------
    private inline fun glow(color: Int, width: Float, k: Float, draw: () -> Unit) {
        gp.color = withAlpha(color, (28 * k).toInt())
        gp.strokeWidth = width * 4.2f
        draw()
        gp.color = withAlpha(color, (70 * k).toInt())
        gp.strokeWidth = width * 2.2f
        draw()
        gp.color = withAlpha(color, (255 * k).toInt())
        gp.strokeWidth = width
        draw()
    }

    private fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        align: Paint.Align = Paint.Align.CENTER, mono: Boolean = false
    ) {
        tp.textSize = size
        tp.color = color
        tp.textAlign = align
        tp.typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT_BOLD
        tp.isFakeBoldText = true
        tp.setShadowLayer(size * 0.3f, 0f, 0f, color)
        c.drawText(s, x, y, tp)
        tp.clearShadowLayer()
    }

    private fun button(c: Canvas, r: RectF, label: String, color: Int, active: Boolean, size: Float, filled: Boolean = false) {
        val rad = hu * 2.2f
        fp.color = withAlpha(color, if (active) 120 else if (filled) 70 else 24)
        c.drawRoundRect(r, rad, rad, fp)
        glow(color, hu * 0.4f, if (active) 1f else 0.65f) { c.drawRoundRect(r, rad, rad, gp) }
        text(c, label, r.centerX(), r.centerY() + size * 0.34f, size, if (active) Color.WHITE else color)
    }

    private fun wheelColor(v: Float): Int =
        if (abs(v) < 0.03f) Color.parseColor("#3A4660") else if (v > 0f) LIME else MAGENTA

    private fun wheel(c: Canvas, cx: Float, cy: Float, v: Float) {
        val ww = hu * 3.6f
        val wh = hu * 6.6f
        rect.set(cx - ww / 2f, cy - wh / 2f, cx + ww / 2f, cy + wh / 2f)
        val col = wheelColor(v)
        val a = abs(v)
        fp.color = withAlpha(col, (60 + 195 * a).toInt())
        c.drawRoundRect(rect, ww * 0.3f, ww * 0.3f, fp)
        glow(col, hu * 0.3f, 0.35f + 0.65f * a) { c.drawRoundRect(rect, ww * 0.3f, ww * 0.3f, gp) }
    }

    // สายฟ้า
    private fun bolt(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, color: Int, jag: Float) {
        path.reset()
        path.moveTo(x1, y1)
        val n = 7
        for (i in 1 until n) {
            val f = i / n.toFloat()
            path.lineTo(
                x1 + (x2 - x1) * f + (rnd.nextFloat() - 0.5f) * jag,
                y1 + (y2 - y1) * f + (rnd.nextFloat() - 0.5f) * jag
            )
        }
        path.lineTo(x2, y2)
        glow(color, hu * 0.35f, 1f) { c.drawPath(path, gp) }
    }

    // เปลวไฟท้ายรถ (dirY = +1 พุ่งลง, -1 พุ่งขึ้น)
    private fun flame(c: Canvas, x: Float, y: Float, dirY: Float, len: Float, wid: Float) {
        val layers = 3
        for (i in 0 until layers) {
            val k = 1f - i * 0.30f
            val fl = (0.75f + 0.25f * rnd.nextFloat()) * len * k
            val w = wid * k
            path.reset()
            path.moveTo(x - w, y)
            path.quadTo(x - w * 0.8f, y + dirY * fl * 0.6f, x + (rnd.nextFloat() - 0.5f) * w * 0.5f, y + dirY * fl)
            path.quadTo(x + w * 0.8f, y + dirY * fl * 0.6f, x + w, y)
            path.close()
            fp.color = when (i) { 0 -> withAlpha(RED, 150); 1 -> withAlpha(ORANGE, 210); else -> withAlpha(YELLOW, 255) }
            c.drawPath(path, fp)
        }
    }

    // ---------------- วาด ----------------
    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1e9f).coerceIn(0f, 0.05f)
        lastNs = now
        clock += dt
        intro += dt
        update(dt)

        c.save()
        c.translate(shakeX, shakeY)

        val col = heat(power)
        val cx = W * 0.5f
        val cy = H * 0.40f
        val dir = if (avg >= 0f) 1f else -1f

        // พื้นหลัง
        c.drawRect(-hu * 4f, -hu * 4f, W + hu * 4f, H + hu * 4f, bg)
        c.drawRect(0f, 0f, W, H, g1)
        c.drawRect(0f, 0f, W, H, g2)

        // กริดพื้นที่วิ่ง
        val horizon = H * 0.5f
        gp.strokeWidth = 2f
        for (i in 0 until 9) {
            val f = ((((i + gridT) % 9f) + 9f) % 9f) / 9f
            val y = horizon + (H - horizon) * f * f
            gp.color = withAlpha(CYAN, (18 + 60 * f).toInt())
            c.drawLine(0f, y, W, y, gp)
        }
        for (k in -12..12) {
            gp.color = withAlpha(MAGENTA, 30)
            c.drawLine(W / 2f + k * W * 0.02f, horizon, W / 2f + k * W * 0.10f, H, gp)
        }

        // แสงขอบจอ เปลี่ยนสี/ความแรงตามกำลัง
        val ea = (30 + 170 * power).toInt()
        fp.shader = LinearGradient(0f, 0f, W * 0.2f, 0f, withAlpha(col, ea), 0, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W * 0.2f, H, fp)
        fp.shader = LinearGradient(W, 0f, W * 0.8f, 0f, withAlpha(col, ea), 0, Shader.TileMode.CLAMP)
        c.drawRect(W * 0.8f, 0f, W, H, fp)
        fp.shader = null

        // Redline: ขอบบน/ล่างแดงกะพริบเมื่อกำลังเกิน 85%
        if (power > 0.85f && !estop) {
            val rl = (0.5f + 0.5f * sin(clock * 14f)) * ((power - 0.85f) / 0.15f)
            fp.shader = LinearGradient(0f, 0f, 0f, H * 0.18f, withAlpha(RED, (150 * rl).toInt()), 0, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, W, H * 0.18f, fp)
            fp.shader = LinearGradient(0f, H, 0f, H * 0.82f, withAlpha(RED, (150 * rl).toInt()), 0, Shader.TileMode.CLAMP)
            c.drawRect(0f, H * 0.82f, W, H, fp)
            fp.shader = null
        }

        // เส้นความเร็ว
        gp.strokeWidth = hu * 0.35f
        for (i in 0 until NS) {
            val len = H * (0.02f + 0.32f * power) * sl[i]
            gp.color = withAlpha(col, (22 + 130 * power).toInt())
            c.drawLine(sx[i], sy[i], sx[i], sy[i] - dir * len, gp)
        }

        // คลื่นกระแทก
        for (i in 0 until 3) {
            val a = ringAge[i]
            if (a >= 0f) {
                val rr = hu * 12f + a * H * 0.95f
                glow(ringCol[i], hu * 0.8f, 1f - a) { c.drawCircle(cx, cy, rr, gp) }
            }
        }

        // ---------- แท่งคันเร่ง (ซ้าย) ----------
        val tx = W * 0.15f
        val tTop = H * 0.21f
        val tBot = H * 0.93f
        val tMid = (tTop + tBot) / 2f
        val tHalf = (tBot - tTop) / 2f
        glow(CYAN, hu * 0.5f, 0.55f) { c.drawLine(tx, tTop - hu * 2f, tx, tBot + hu * 2f, gp) }
        for (i in 0..8) {
            val y = tTop + (tBot - tTop) * i / 8f
            val big = (i == 0 || i == 4 || i == 8)
            gp.color = withAlpha(CYAN, if (big) 200 else 90)
            gp.strokeWidth = hu * 0.35f
            c.drawLine(tx - hu * (if (big) 5f else 3f), y, tx + hu * (if (big) 5f else 3f), y, gp)
        }
        val tKnobY = tMid - thrVis * tHalf
        val tCol = if (thrVis >= 0f) heat(abs(thrVis)) else lerpColor(MAGENTA, RED, abs(thrVis))
        glow(tCol, hu * 1.6f, 0.95f) { c.drawLine(tx, tMid, tx, tKnobY, gp) }
        text(c, "THROTTLE", tx, H * 0.17f, hu * 3.4f, CYAN)
        text(c, "FWD", tx + hu * 11f, tTop + hu * 1.2f, hu * 2.8f, LIME)
        text(c, "REV", tx + hu * 11f, tBot + hu * 1.2f, hu * 2.8f, MAGENTA)
        fp.color = Color.parseColor("#0A0F1E")
        c.drawCircle(tx, tKnobY, hu * 8.5f, fp)
        glow(tCol, hu * 0.6f, 1f) { c.drawCircle(tx, tKnobY, hu * 8.5f, gp) }
        glow(tCol, hu * 0.3f, 0.7f) { c.drawCircle(tx, tKnobY, hu * 4.8f, gp) }

        // ---------- แท่งพวงมาลัย (ขวา) ----------
        val sCx = W * 0.85f
        val sHalf = W * 0.13f
        val sy0 = H * 0.64f
        glow(CYAN, hu * 0.5f, 0.55f) { c.drawLine(sCx - sHalf - hu * 2f, sy0, sCx + sHalf + hu * 2f, sy0, gp) }
        for (i in 0..8) {
            val x = sCx - sHalf + 2f * sHalf * i / 8f
            val big = (i == 0 || i == 4 || i == 8)
            gp.color = withAlpha(CYAN, if (big) 200 else 90)
            gp.strokeWidth = hu * 0.35f
            c.drawLine(x, sy0 - hu * (if (big) 5f else 3f), x, sy0 + hu * (if (big) 5f else 3f), gp)
        }
        val sKnobX = sCx + steerVis * sHalf
        val sCol = lerpColor(CYAN, MAGENTA, abs(steerVis))
        glow(sCol, hu * 1.6f, 0.95f) { c.drawLine(sCx, sy0, sKnobX, sy0, gp) }
        text(c, "STEER", sCx, H * 0.50f, hu * 3.4f, CYAN)
        text(c, "L", sCx - sHalf, sy0 + hu * 12f, hu * 3.4f, MAGENTA)
        text(c, "R", sCx + sHalf, sy0 + hu * 12f, hu * 3.4f, MAGENTA)
        fp.color = Color.parseColor("#0A0F1E")
        c.drawCircle(sKnobX, sy0, hu * 8.5f, fp)
        glow(sCol, hu * 0.6f, 1f) { c.drawCircle(sKnobX, sy0, hu * 8.5f, gp) }
        glow(sCol, hu * 0.3f, 0.7f) { c.drawCircle(sKnobX, sy0, hu * 4.8f, gp) }

        // ---------- เกจกำลัง + ความเร็ว ----------
        val R = H * 0.235f
        oval.set(cx - R, cy - R, cx + R, cy + R)
        val pulse = 0.5f + 0.5f * sin(clock * (3f + 6f * power))
        gp.strokeWidth = hu * 0.4f
        gp.color = withAlpha(col, (30 + 80 * pulse * (0.3f + power)).toInt())
        c.drawCircle(cx, cy, R * 1.17f, gp)
        glow(CYAN, hu * 0.9f, 0.18f) { c.drawArc(oval, 135f, 270f, false, gp) }
        if (power > 0.005f) {
            glow(col, hu * 1.1f, 1f) { c.drawArc(oval, 135f, 270f * power, false, gp) }
        }
        for (i in 0..10) {
            val ang = (135f + 27f * i) * (PI.toFloat() / 180f)
            val on = i / 10f <= power + 0.001f
            val red = i >= 9
            gp.color = withAlpha(if (on) col else if (red) RED else CYAN, if (on) 255 else if (red) 140 else 70)
            gp.strokeWidth = hu * 0.4f
            c.drawLine(
                cx + cos(ang) * R * 1.07f, cy + sin(ang) * R * 1.07f,
                cx + cos(ang) * R * 1.14f, cy + sin(ang) * R * 1.14f, gp
            )
        }
        val spdTxt = if (enc) spdDisp.roundToInt().toString() else spdDisp.roundToInt().toString()
        text(c, spdTxt, cx, cy + R * 0.93f, hu * 8.6f, Color.WHITE, mono = true)
        text(c, if (enc) "SPEED cm/s" else "SPEED % (EST)", cx, cy + R * 0.93f + hu * 4.2f, hu * 2.5f, col)
        text(c, "PWR ${(power * 100f).roundToInt()}%   MAX ${spdMax.roundToInt()}", cx, cy + R * 0.93f + hu * 7.4f, hu * 2.3f, withAlpha(CYAN, 200))
        val state = when {
            estop -> "E-STOP"
            power < 0.03f -> "IDLE"
            dispL * dispR < -0.01f -> "SPIN"
            abs(dispL) < 0.03f || abs(dispR) < 0.03f -> "PIVOT"
            avg > 0f -> "FORWARD"
            else -> "REVERSE"
        }
        text(c, state, cx, cy - R * 0.78f, hu * 3.2f, if (estop) RED else col)

        // สายฟ้ารอบตัวรถ เมื่อกำลังสูง
        if (power > 0.6f && !estop) {
            val n = if (power > 0.9f) 4 else if (power > 0.75f) 3 else 2
            for (i in 0 until n) {
                val a = rnd.nextFloat() * 2f * PI.toFloat()
                val r1 = hu * 9f
                val r2 = R * (1.0f + 0.2f * rnd.nextFloat())
                bolt(c, cx + cos(a) * r1, cy + sin(a) * r1, cx + cos(a) * r2, cy + sin(a) * r2,
                    if (rnd.nextBoolean()) CYAN else MAGENTA, hu * 5f)
            }
        }

        // ประกายไฟ
        for (j in 0 until NP) {
            if (pl[j] > 0f) {
                fp.color = withAlpha(lerpColor(RED, ORANGE, pl[j]), (255 * pl[j]).toInt())
                c.drawCircle(px[j], py[j], hu * (0.3f + 0.9f * pl[j]), fp)
            }
        }

        // แสงใต้ท้องรถ
        fp.shader = RadialGradient(cx, cy, hu * 22f, withAlpha(col, (30 + 120 * power).toInt()), 0, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, hu * 22f, fp)
        fp.shader = null

        // ---------- ตัวรถ (มองจากด้านบน หัวรถอยู่ด้านบน) ----------
        val bl = hu * 26f
        val bw = hu * 13f

        // ลำแสงไฟหน้า
        val fwdP = max(0f, avg)
        val beamTop = cy - bl / 2f
        val beamA = (45 + 130 * fwdP).toInt()
        for (side in intArrayOf(-1, 1)) {
            val x0 = cx + side * bw * 0.30f
            path.reset()
            path.moveTo(x0 - hu * 0.8f, beamTop)
            path.lineTo(x0 + hu * 0.8f, beamTop)
            path.lineTo(x0 + side * hu * 7f + hu * 5f, beamTop - hu * (16f + 18f * fwdP))
            path.lineTo(x0 + side * hu * 7f - hu * 5f, beamTop - hu * (16f + 18f * fwdP))
            path.close()
            fp.shader = LinearGradient(0f, beamTop, 0f, beamTop - hu * 34f,
                withAlpha(Color.parseColor("#FFF59D"), beamA), 0, Shader.TileMode.CLAMP)
            c.drawPath(path, fp)
            fp.shader = null
        }

        // เปลวไฟท้าย (หรือหน้า ตอนถอย)
        if (power > 0.10f && !estop) {
            val fy = cy + dir * bl / 2f
            val fl = hu * (5f + 22f * power)
            flame(c, cx - bw * 0.30f, fy, dir, fl, hu * (1.2f + 1.6f * power))
            flame(c, cx + bw * 0.30f, fy, dir, fl, hu * (1.2f + 1.6f * power))
        }

        rect.set(cx - bw / 2f, cy - bl / 2f, cx + bw / 2f, cy + bl / 2f)
        fp.color = Color.parseColor("#E60A0F1E")
        c.drawRoundRect(rect, hu * 3f, hu * 3f, fp)
        glow(CYAN, hu * 0.5f, 0.9f) { c.drawRoundRect(rect, hu * 3f, hu * 3f, gp) }
        rect.set(cx - bw * 0.32f, cy - bl * 0.22f, cx + bw * 0.32f, cy + bl * 0.18f)
        fp.color = withAlpha(CYAN, 38)
        c.drawRoundRect(rect, hu * 2f, hu * 2f, fp)
        gp.color = withAlpha(CYAN, 120)
        gp.strokeWidth = hu * 0.3f
        c.drawRoundRect(rect, hu * 2f, hu * 2f, gp)
        val wx = bw / 2f + hu * 0.8f
        val wyF = cy - bl * 0.30f
        val wyR = cy + bl * 0.30f
        wheel(c, cx - wx, wyF, dispL)
        wheel(c, cx - wx, wyR, dispL)
        wheel(c, cx + wx, wyF, dispR)
        wheel(c, cx + wx, wyR, dispR)
        // ไฟหน้า / ไฟท้าย
        fp.color = withAlpha(Color.parseColor("#FFF59D"), (90 + 165 * fwdP).toInt())
        c.drawCircle(cx - bw * 0.30f, cy - bl / 2f + hu * 1.6f, hu * 1.2f, fp)
        c.drawCircle(cx + bw * 0.30f, cy - bl / 2f + hu * 1.6f, hu * 1.2f, fp)
        val rev = if (avg < -0.03f) 1f else 0f
        fp.color = withAlpha(RED, (90 + 165 * rev).toInt())
        c.drawCircle(cx - bw * 0.30f, cy + bl / 2f - hu * 1.6f, hu * 1.2f, fp)
        c.drawCircle(cx + bw * 0.30f, cy + bl / 2f - hu * 1.6f, hu * 1.2f, fp)

        // ---------- ปุ่ม ----------
        val gearNames = arrayOf("ECO", "SPORT", "TURBO")
        val gearCols = intArrayOf(LIME, CYAN, RED)
        for (i in 0..2) button(c, rGear[i], gearNames[i], gearCols[i], gear == i, hu * 3.6f)
        button(c, rMode, if (pivot) "TURN: PIVOT" else "TURN: SPIN", MAGENTA, pivot, hu * 3.0f)
        button(c, rEstop, if (estop) "RELEASE" else "E-STOP", RED, estop, hu * 3.6f, filled = true)
        button(c, rSetup, "SETUP", CYAN, false, hu * 3.0f)
        button(c, rDisc, "DISCONNECT", RED, false, hu * 2.8f)

        // ---------- แถบสถานะ ----------
        val alive = System.currentTimeMillis() - lastTeleMs < 2000
        val blink = 0.5f + 0.5f * sin(clock * 6f)
        fp.color = withAlpha(if (alive) LIME else RED, (120 + 135 * (if (alive) 1f else blink)).toInt())
        c.drawCircle(W * 0.03f, H * 0.065f, hu * 1.6f, fp)
        val st = if (alive) "$deviceName  |  LINK OK  |  L:${fmt(outL)}  R:${fmt(outR)}"
        else "NO SIGNAL FROM ESP32  (ต้องอัปโหลดเฟิร์มแวร์ v4)"
        text(c, st, W * 0.05f, H * 0.065f + hu * 1.3f, hu * 3.1f, if (alive) CYAN else RED, Paint.Align.LEFT)

        // ---------- E-STOP overlay ----------
        if (estop) {
            val fl = 0.5f + 0.5f * sin(clock * 9f)
            rect.set(hu, hu, W - hu, H - hu)
            gp.color = withAlpha(RED, (90 + 150 * fl).toInt())
            gp.strokeWidth = hu * 1.4f
            c.drawRoundRect(rect, hu * 3f, hu * 3f, gp)
            text(c, "E-STOP", cx, H * 0.36f, hu * 15f, withAlpha(RED, (40 + 40 * fl).toInt()))
        }

        // ---------- อนิเมชันเปิดเครื่อง ----------
        if (intro < 1.3f) {
            val f = intro / 1.3f
            val y = H * f
            glow(CYAN, hu * 0.5f, 1f - f) { c.drawLine(0f, y, W, y, gp) }
            text(c, "SYSTEM ONLINE", cx, H * 0.5f, hu * 7f, withAlpha(CYAN, (255 * (1f - f)).toInt()))
        }

        c.restore()
        postInvalidateOnAnimation()
    }

    private fun fmt(v: Int): String = if (v > 0) "+$v" else "$v"
}

// ---------------------------------------------------------------
// กิจกรรมหลัก
// ---------------------------------------------------------------
@SuppressLint("MissingPermission", "ClickableViewAccessibility")
class MainActivity : Activity() {

    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()   // เขียนอย่างเดียว
    private val pending = java.util.concurrent.atomic.AtomicInteger(0)

    private var adapter: BluetoothAdapter? = null
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null
    @Volatile private var connected = false
    private var deviceName = "-"

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private var listBox: LinearLayout? = null
    private var drive: DriveView? = null
    private var screen = 0            // 0 เริ่ม, 1 เลือกอุปกรณ์, 2 ขับ, 3 ตั้งค่า

    private var testL = 0
    private var testR = 0
    private var testUntil = 0L
    private val cfg = IntArray(6)     // กลับทิศมอเตอร์ 0-3, สลับซ้ายขวา, PWM เริ่มต้น
    private val invBtns = arrayOfNulls<Button>(4)
    private var swapBtn: Button? = null
    private var minTv: TextView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun glowText(text: String, size: Float, color: Int, glow: Int = color) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setShadowLayer(18f, 0f, 0f, glow)
    }

    private fun title(text: String, size: Float) = glowText(text, size, Color.WHITE, CYAN).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        letterSpacing = 0.1f
        val wpx = paint.measureText(text) * 1.3f
        paint.shader = LinearGradient(0f, 0f, wpx, 0f, CYAN, MAGENTA, Shader.TileMode.CLAMP)
    }

    private fun btn(text: String, size: Float, c: Int): Button = Button(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        isAllCaps = false
        background = GradientDrawable().apply {
            setColor(withAlpha(c, 40))
            setStroke(dp(2), c)
            cornerRadius = dp(14).toFloat()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        root = FrameLayout(this)
        root.addView(GridBackground(this), FrameLayout.LayoutParams(-1, -1))
        content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        showStart()
    }

    @Suppress("DEPRECATION")
    private fun hideBars(hide: Boolean) {
        window.decorView.systemUiVisibility = if (hide)
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        else View.SYSTEM_UI_FLAG_VISIBLE
    }

    private fun setScreen(v: View, id: Int, padded: Boolean = true) {
        screen = id
        hideBars(id == 2)
        content.removeAllViews()
        if (padded) content.setPadding(dp(20), dp(8), dp(20), dp(8)) else content.setPadding(0, 0, 0, 0)
        content.addView(v, FrameLayout.LayoutParams(-1, -1))
    }

    // ---------- หน้าเริ่มต้น ----------
    private fun showStart() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        col.addView(title("THEP 4WD", 52f))
        col.addView(glowText("B L U E T O O T H   R C   C O N T R O L L E R   v4", 11f, CYAN))
        val c = NeonButton(this, "CONNECT BLUETOOTH", CYAN, 17f)
        c.onClick = { ensurePermissions { showDevices() } }
        col.addView(c, LinearLayout.LayoutParams(dp(320), dp(96)).apply { topMargin = dp(18) })
        col.addView(glowText("จับคู่ THEP_4WD ใน Settings > Bluetooth ก่อนใช้งาน", 11f, Color.LTGRAY, MAGENTA))
        setScreen(col, 0)
    }

    // ---------- หน้าเลือกอุปกรณ์ ----------
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private val receiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == BluetoothDevice.ACTION_FOUND) {
                val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33)
                    i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                else
                    i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                if (d != null && !found.containsKey(d.address)) {
                    found[d.address] = d
                    refreshList()
                }
            }
        }
    }
    private var receiverOn = false

    private fun showDevices() {
        val a = adapter
        if (a == null) { toast("เครื่องนี้ไม่มี Bluetooth"); return }
        if (!a.isEnabled) { toast("กรุณาเปิด Bluetooth ก่อน"); return }
        found.clear()
        a.bondedDevices.forEach { found[it.address] = it }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(glowText("เลือกอุปกรณ์  →  THEP_4WD", 20f, CYAN))
        val lb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listBox = lb
        col.addView(ScrollView(this).apply { addView(lb) }, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this)
        val scan = btn("ค้นหาอุปกรณ์", 16f, CYAN)
        val back = btn("กลับ", 16f, Color.GRAY)
        scan.setOnClickListener { startScan() }
        back.setOnClickListener { stopScan(); showStart() }
        row.addView(scan, LinearLayout.LayoutParams(0, dp(56), 1f).apply { marginEnd = dp(8) })
        row.addView(back, LinearLayout.LayoutParams(0, dp(56), 1f))
        col.addView(row)
        setScreen(col, 1)
        refreshList()
    }

    private fun refreshList() {
        val lb = listBox ?: return
        lb.removeAllViews()
        val sorted = found.values.sortedByDescending { it.name == "THEP_4WD" }
        for (d in sorted) {
            val name = d.name ?: "(ไม่มีชื่อ)"
            val isCar = name == "THEP_4WD"
            val b = btn("$name\n${d.address}", 16f, if (isCar) MAGENTA else Color.GRAY)
            b.setOnClickListener { stopScan(); connect(d) }
            lb.addView(b, LinearLayout.LayoutParams(-1, dp(72)).apply { topMargin = dp(6) })
        }
    }

    private fun startScan() {
        if (!receiverOn) {
            registerReceiver(receiver, IntentFilter(BluetoothDevice.ACTION_FOUND))
            receiverOn = true
        }
        adapter?.cancelDiscovery()
        adapter?.startDiscovery()
        toast("กำลังค้นหา...")
    }

    private fun stopScan() {
        adapter?.cancelDiscovery()
        if (receiverOn) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverOn = false
        }
    }

    // ---------- เชื่อมต่อ ----------
    private fun connect(d: BluetoothDevice) {
        toast("กำลังเชื่อมต่อ ${d.name}...")
        Thread {
            try {
                try { socket?.close() } catch (_: Exception) {}
                val s = d.createRfcommSocketToServiceRecord(SPP)
                adapter?.cancelDiscovery()
                s.connect()
                socket = s
                out = s.outputStream
                connected = true
                deviceName = d.name ?: d.address
                ui.post {
                    drive = null
                    showControl()
                    ui.removeCallbacks(tick)
                    ui.post(tick)
                    sendLine("G")
                }
                readLoop(s.inputStream)
            } catch (e: Exception) {
                connected = false
                ui.post { toast("เชื่อมต่อไม่สำเร็จ: ${e.message}") }
            }
        }.start()
    }

    private fun readLoop(input: InputStream) {
        val buf = ByteArray(256)
        val sb = StringBuilder()
        try {
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                sb.append(String(buf, 0, n))
                while (true) {
                    val idx = sb.indexOf("\n")
                    if (idx < 0) break
                    val line = sb.substring(0, idx).trim()
                    sb.delete(0, idx + 1)
                    handleLine(line)
                }
                if (sb.length > 512) sb.setLength(0)
            }
        } catch (_: Exception) {}
        if (connected) {
            connected = false
            ui.post { onLost() }
        }
    }

    // T,curL,curR,spdL,spdR,enc   |  CFG,inv0..3,swap,minPwm  |  FS
    private fun handleLine(line: String) {
        if (line.startsWith("T,")) {
            val d = drive ?: return
            d.lastTeleMs = System.currentTimeMillis()
            val p = line.split(",")
            if (p.size >= 6) {
                d.spdL = p[3].trim().toFloatOrNull() ?: 0f
                d.spdR = p[4].trim().toFloatOrNull() ?: 0f
                d.enc = p[5].trim() == "1"
            }
        } else if (line.startsWith("CFG,")) {
            val parts = line.substring(4).split(",")
            for (i in 0 until min(6, parts.size)) cfg[i] = parts[i].trim().toIntOrNull() ?: 0
            ui.post { refreshSetupButtons() }
        } else if (line.startsWith("FS")) {
            ui.post { toast("Failsafe: ESP32 หยุดรถเอง (ไม่ได้รับคำสั่ง)") }
        }
    }

    private fun onLost() {
        toast("Bluetooth หลุด")
        ui.removeCallbacks(tick)
        drive?.resetInputs()
        closeSocket()
        showStart()
    }

    // ส่งคำสั่งขับ 25 ครั้ง/วินาที (เป็น heartbeat ด้วย)
    // ถ้าคิวเขียนค้าง (บลูทูธช้า) จะข้ามเฟรม เพื่อไม่ให้คำสั่งเก่าสะสมจนรถ "ตอบช้า/สวนทาง"
    private val tick = object : Runnable {
        override fun run() {
            if (!connected) return
            var l = 0
            var r = 0
            if (System.currentTimeMillis() < testUntil) {
                l = testL; r = testR
            } else if (screen == 2) {
                drive?.let { l = it.outL; r = it.outR }
            }
            if (pending.get() < 2) sendLine("M,$l,$r")
            ui.postDelayed(this, 40)
        }
    }

    private fun sendLine(s: String) {
        pending.incrementAndGet()
        io.execute {
            try {
                out?.write((s + "\n").toByteArray())
                out?.flush()
            } catch (e: Exception) {
                if (connected) {
                    connected = false
                    ui.post { onLost() }
                }
            } finally {
                pending.decrementAndGet()
            }
        }
    }

    private fun disconnect() {
        ui.removeCallbacks(tick)
        drive?.resetInputs()
        testUntil = 0L
        sendLine("S")
        io.execute { Thread.sleep(200); closeSocket() }
        connected = false
        showStart()
    }

    private fun closeSocket() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        out = null
        connected = false
    }

    // ---------- หน้าขับรถ ----------
    private fun showControl() {
        val dv = drive ?: DriveView(this).also {
            it.deviceName = deviceName
            it.onDisconnect = { disconnect() }
            it.onSetup = { showSetup() }
            drive = it
        }
        dv.resetInputs()
        setScreen(dv, 2, padded = false)
    }

    // ---------- หน้าตั้งค่า/ทดสอบมอเตอร์ ----------
    private fun runTest(l: Int, r: Int, ms: Long) {
        testL = l; testR = r
        testUntil = System.currentTimeMillis() + ms
    }

    private fun showSetup() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(glowText("SETUP  •  ทดสอบและตั้งทิศมอเตอร์", 18f, CYAN))
        col.addView(glowText("ยกรถลอยล้อก่อนทดสอบทุกครั้ง!", 12f, ORANGE))

        col.addView(glowText("1) ทดสอบทั้งคัน (หมุน 1 วินาที)", 13f, Color.WHITE),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val r1 = LinearLayout(this)
        val bF = btn("เดินหน้า", 14f, LIME)
        val bL = btn("หมุนซ้าย", 14f, MAGENTA)
        val bR = btn("หมุนขวา", 14f, MAGENTA)
        bF.setOnClickListener { runTest(55, 55, 1000) }
        bL.setOnClickListener { runTest(-55, 55, 1000) }
        bR.setOnClickListener { runTest(55, -55, 1000) }
        for (b in arrayOf(bF, bL, bR)) r1.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        col.addView(r1)
        col.addView(glowText("เดินหน้า: ล้อทั้ง 4 ต้องหมุนไปข้างหน้า | หมุนซ้าย: ตัวรถต้องหมุนทวนเข็มนาฬิกา", 10f, Color.LTGRAY, CYAN))

        col.addView(glowText("2) ทดสอบทีละมอเตอร์ แล้วกด \"ทิศ\" ถ้าล้อหมุนถอยหลัง", 13f, Color.WHITE),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val names = arrayOf("มอเตอร์ 1 (ตัวที่ 1 ช่อง A)", "มอเตอร์ 2 (ตัวที่ 1 ช่อง B)",
            "มอเตอร์ 3 (ตัวที่ 2 ช่อง A)", "มอเตอร์ 4 (ตัวที่ 2 ช่อง B)")
        for (i in 0..3) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val lab = glowText(names[i], 12f, CYAN).apply { gravity = Gravity.START }
            val test = btn("ทดสอบ", 13f, LIME)
            val inv = btn("", 13f, MAGENTA)
            invBtns[i] = inv
            test.setOnClickListener { sendLine("T,$i") }
            inv.setOnClickListener {
                val nv = 1 - cfg[i]
                cfg[i] = nv
                sendLine("V,$i,$nv")
                refreshSetupButtons()
            }
            row.addView(lab, LinearLayout.LayoutParams(0, -2, 1.3f))
            row.addView(test, LinearLayout.LayoutParams(0, dp(44), 0.7f).apply { marginEnd = dp(6) })
            row.addView(inv, LinearLayout.LayoutParams(0, dp(44), 0.8f))
            col.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        }

        col.addView(glowText("3) ถ้า \"หมุนซ้าย\" แล้วรถหมุนขวา ให้สลับซ้าย/ขวา", 13f, Color.WHITE),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val sw = btn("", 13f, ORANGE)
        swapBtn = sw
        sw.setOnClickListener {
            val nv = 1 - cfg[4]
            cfg[4] = nv
            sendLine("V,4,$nv")
            refreshSetupButtons()
        }
        col.addView(sw, LinearLayout.LayoutParams(-1, dp(44)))

        // 4) แรงเริ่มหมุน (PWM ต่ำสุด) แก้อาการ "กดเบาๆ แล้วไม่ไป/อืด"
        col.addView(glowText("4) แรงเริ่มหมุน: เพิ่มถ้าดันนิดเดียวแล้วรถไม่ขยับ ลดถ้าออกตัวกระชาก", 13f, Color.WHITE),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val mrow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val mm = btn("-", 18f, CYAN)
        val mp = btn("+", 18f, CYAN)
        val tv = glowText("", 18f, LIME)
        minTv = tv
        mm.setOnClickListener { cfg[5] = (cfg[5] - 5).coerceIn(0, 160); sendLine("P,${cfg[5]}"); refreshSetupButtons() }
        mp.setOnClickListener { cfg[5] = (cfg[5] + 5).coerceIn(0, 160); sendLine("P,${cfg[5]}"); refreshSetupButtons() }
        mrow.addView(mm, LinearLayout.LayoutParams(0, dp(48), 1f))
        mrow.addView(tv, LinearLayout.LayoutParams(0, -2, 1.4f))
        mrow.addView(mp, LinearLayout.LayoutParams(0, dp(48), 1f))
        col.addView(mrow)

        val back = btn("กลับไปหน้าควบคุม", 15f, CYAN)
        back.setOnClickListener { testUntil = 0L; sendLine("S"); showControl() }
        col.addView(back, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(12) })

        setScreen(ScrollView(this).apply { addView(col) }, 3)
        refreshSetupButtons()
        sendLine("G")
    }

    private fun refreshSetupButtons() {
        if (screen != 3) return
        for (i in 0..3) invBtns[i]?.text = if (cfg[i] == 1) "ทิศ: กลับ" else "ทิศ: ปกติ"
        swapBtn?.text = if (cfg[4] == 1) "ซ้าย/ขวา: สลับแล้ว (กดเพื่อกลับ)" else "ซ้าย/ขวา: ปกติ (กดเพื่อสลับ)"
        minTv?.text = "PWM เริ่มต้น: ${cfg[5]}"
    }

    // ---------- Permission ----------
    private var afterPerm: (() -> Unit)? = null

    private fun ensurePermissions(then: () -> Unit) {
        val need = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) then() else {
            afterPerm = then
            requestPermissions(missing.toTypedArray(), 1)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) afterPerm?.invoke()
        else toast("ต้องอนุญาต Permission Bluetooth ก่อนใช้งาน")
        afterPerm = null
    }

    // ---------- ความปลอดภัย ----------
    override fun onPause() {
        super.onPause()
        drive?.resetInputs()
        testUntil = 0L
        if (connected) sendLine("S")
    }

    override fun onDestroy() {
        stopScan()
        ui.removeCallbacks(tick)
        if (connected) {
            try { out?.write("S\n".toByteArray()); out?.flush() } catch (_: Exception) {}
        }
        closeSocket()
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
