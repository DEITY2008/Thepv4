// ============================================================
//  THEP 4WD  -  ESP32 firmware v4  (Bluetooth Classic SPP)
//  โปรโตคอลเข้ากับแอป v4:
//    app -> esp : M,l,r | S | G | T,i | V,i,v | P,n      (l,r = -100..100)
//    esp -> app : T,curL,curR,spdL,spdR,enc | CFG,inv0..3,swap,minPwm | FS
//  แก้อาการ "กดไปแล้วไม่ไป/ช้า/สวนทาง":
//    - อ่านบลูทูธแบบ non-blocking (ไม่มี readStringUntil ที่ค้าง/คิวสะสม)
//    - PWM ขั้นต่ำ (minPwm) ชดเชยช่วงที่มอเตอร์ยังไม่หมุน
//    - ramp เร่ง/เบรกนุ่ม ไม่กระชากจนไฟตก (brown-out)
//    - failsafe หยุดรถถ้าไม่มีคำสั่ง > 500 ms
// ============================================================
#include <BluetoothSerial.h>
#include <Preferences.h>

// ---------- ตั้งค่าขา: แก้ให้ตรงกับบอร์ดของคุณ ----------
// แต่ละมอเตอร์ใช้ 2 ขา (IN1/IN2) ใส่ PWM ที่ขาที่ "กำลังหมุน"
// ใช้ได้กับ L298N(ถอดจัมเปอร์ EN ใส่ 5V) / L9110 / DRV8833 / TB6612(PWMA/B ต่อ 3V3)
//   มอเตอร์ 0,1 = ฝั่งซ้าย    มอเตอร์ 2,3 = ฝั่งขวา
const int IN1[4] = {25, 27, 32, 18};
const int IN2[4] = {26, 14, 33, 19};

// ---------- Encoder (ไม่บังคับ) ----------
#define USE_ENCODER 0          // เปลี่ยนเป็น 1 ถ้าต่อ encoder/ตัวจับรอบ
const int ENC_L_PIN = 34;      // ขาสัญญาณ encoder ฝั่งซ้าย
const int ENC_R_PIN = 35;      // ขาสัญญาณ encoder ฝั่งขวา
const float PULSES_PER_REV = 20.0f;  // พัลส์ต่อ 1 รอบล้อ
const float WHEEL_CM = 6.5f;         // เส้นผ่านศูนย์กลางล้อ (ซม.)

const int PWM_FREQ = 20000;    // 20kHz เงียบ ไม่หอน
const int PWM_BITS = 8;
const unsigned long FAILSAFE_MS = 500;
const float ACC_RATE = 500.0f;   // %/วินาที ตอนเร่ง
const float DEC_RATE = 1000.0f;  // %/วินาที ตอนผ่อน/เบรก/กลับทิศ

BluetoothSerial SerialBT;
Preferences prefs;

int inv[4] = {0, 0, 0, 0};
int swapLR = 0;
int minPwm = 70;

float tgtL = 0, tgtR = 0, curL = 0, curR = 0;
unsigned long lastCmd = 0, lastCtl = 0, lastTele = 0, testUntil = 0;
int testIdx = -1;
bool fsSent = false;
String lineBuf;

volatile uint32_t encL = 0, encR = 0;
#if USE_ENCODER
void IRAM_ATTR isrL() { encL++; }
void IRAM_ATTR isrR() { encR++; }
#endif

#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  #define PWM_ATTACH(pin, ch) ledcAttach(pin, PWM_FREQ, PWM_BITS)
  #define PWM_WRITE(pin, ch, duty) ledcWrite(pin, duty)
#else
  #define PWM_ATTACH(pin, ch) do { ledcSetup(ch, PWM_FREQ, PWM_BITS); ledcAttachPin(pin, ch); } while (0)
  #define PWM_WRITE(pin, ch, duty) ledcWrite(ch, duty)
#endif

void setMotorRaw(int i, int duty) {       // duty -255..255
  int a = duty > 0 ? duty : 0;
  int b = duty < 0 ? -duty : 0;
  PWM_WRITE(IN1[i], i * 2, a);
  PWM_WRITE(IN2[i], i * 2 + 1, b);
}

int mapDuty(float v) {                    // v -100..100 -> duty พร้อมชดเชย minPwm
  float m = fabsf(v);
  if (m < 1.5f) return 0;
  int d = minPwm + (int)((255 - minPwm) * (m / 100.0f));
  if (d > 255) d = 255;
  return v < 0 ? -d : d;
}

void applyDrive(float l, float r) {
  if (swapLR) { float t = l; l = r; r = t; }
  int dl = mapDuty(l), dr = mapDuty(r);
  for (int i = 0; i < 4; i++) {
    int d = (i < 2) ? dl : dr;
    if (inv[i]) d = -d;
    setMotorRaw(i, d);
  }
}

void stopAll() {
  tgtL = tgtR = curL = curR = 0;
  testIdx = -1;
  for (int i = 0; i < 4; i++) setMotorRaw(i, 0);
}

void sendCfg() {
  SerialBT.printf("CFG,%d,%d,%d,%d,%d,%d\n", inv[0], inv[1], inv[2], inv[3], swapLR, minPwm);
}

void handleLine(const String &s) {
  int a, b;
  if (s.startsWith("M,")) {
    if (sscanf(s.c_str(), "M,%d,%d", &a, &b) == 2) {
      tgtL = constrain(a, -100, 100);
      tgtR = constrain(b, -100, 100);
      lastCmd = millis();
      fsSent = false;
    }
  } else if (s == "S") {
    stopAll();
    lastCmd = millis();
  } else if (s == "G") {
    sendCfg();
  } else if (s.startsWith("T,")) {
    if (sscanf(s.c_str(), "T,%d", &a) == 1 && a >= 0 && a < 4) {
      tgtL = tgtR = 0; curL = curR = 0;
      testIdx = a; testUntil = millis() + 800;
      lastCmd = millis();
    }
  } else if (s.startsWith("V,")) {
    if (sscanf(s.c_str(), "V,%d,%d", &a, &b) == 2) {
      if (a >= 0 && a < 4) { inv[a] = b ? 1 : 0; prefs.putInt(("inv" + String(a)).c_str(), inv[a]); }
      else if (a == 4) { swapLR = b ? 1 : 0; prefs.putInt("swap", swapLR); }
      sendCfg();
    }
  } else if (s.startsWith("P,")) {
    if (sscanf(s.c_str(), "P,%d", &a) == 1) {
      minPwm = constrain(a, 0, 160);
      prefs.putInt("minpwm", minPwm);
      sendCfg();
    }
  }
}

void readBT() {
  while (SerialBT.available()) {
    char ch = (char)SerialBT.read();
    if (ch == '\n') {
      lineBuf.trim();
      if (lineBuf.length()) handleLine(lineBuf);
      lineBuf = "";
    } else if (ch != '\r') {
      if (lineBuf.length() < 40) lineBuf += ch;
      else lineBuf = "";
    }
  }
}

float stepTo(float cur, float tgt, float dt) {
  float rate = (fabsf(tgt) < fabsf(cur) || tgt * cur < 0) ? DEC_RATE : ACC_RATE;
  float d = tgt - cur, mx = rate * dt;
  if (d > mx) d = mx; else if (d < -mx) d = -mx;
  return cur + d;
}

void setup() {
  prefs.begin("thep", false);
  for (int i = 0; i < 4; i++) inv[i] = prefs.getInt(("inv" + String(i)).c_str(), 0);
  swapLR = prefs.getInt("swap", 0);
  minPwm = prefs.getInt("minpwm", 70);
  for (int i = 0; i < 4; i++) {
    PWM_ATTACH(IN1[i], i * 2);
    PWM_ATTACH(IN2[i], i * 2 + 1);
  }
  stopAll();
#if USE_ENCODER
  pinMode(ENC_L_PIN, INPUT); pinMode(ENC_R_PIN, INPUT);
  attachInterrupt(digitalPinToInterrupt(ENC_L_PIN), isrL, RISING);
  attachInterrupt(digitalPinToInterrupt(ENC_R_PIN), isrR, RISING);
#endif
  SerialBT.begin("THEP_4WD");
  lastCmd = millis();
}

void loop() {
  readBT();
  unsigned long now = millis();

  if (testIdx >= 0) {                     // โหมดทดสอบมอเตอร์ทีละตัว
    if (now < testUntil) {
      for (int i = 0; i < 4; i++) setMotorRaw(i, 0);
      setMotorRaw(testIdx, inv[testIdx] ? -(minPwm + 60) : (minPwm + 60));
    } else stopAll();
    return;
  }

  if (now - lastCmd > FAILSAFE_MS) {      // failsafe
    if (!fsSent && (tgtL != 0 || tgtR != 0 || curL != 0 || curR != 0)) { SerialBT.println("FS"); fsSent = true; }
    tgtL = tgtR = 0;
  }

  if (now - lastCtl >= 10) {
    float dt = (now - lastCtl) / 1000.0f;
    lastCtl = now;
    curL = stepTo(curL, tgtL, dt);
    curR = stepTo(curR, tgtR, dt);
    applyDrive(curL, curR);
  }

  if (now - lastTele >= 100) {
    float dtT = (now - lastTele) / 1000.0f;
    lastTele = now;
    int sl = 0, sr = 0, en = 0;
#if USE_ENCODER
    noInterrupts(); uint32_t a = encL, b = encR; encL = encR = 0; interrupts();
    float cm = WHEEL_CM * 3.14159f / PULSES_PER_REV;
    sl = (int)(a * cm / dtT); sr = (int)(b * cm / dtT);
    if (curL < 0) sl = -sl;          // encoder ช่องเดียว: เดาทิศจากคำสั่ง
    if (curR < 0) sr = -sr;
    en = 1;
#endif
    SerialBT.printf("T,%d,%d,%d,%d,%d\n", (int)curL, (int)curR, sl, sr, en);
  }
}
